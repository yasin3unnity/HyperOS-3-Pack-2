#!/sbin/sh
#
keytest() {
  while true; do
    /system/bin/getevent -lc 1 | grep KEY_VOLUMEUP >/dev/null && sleep 0.5 && return 0
    /system/bin/getevent -lc 1 | grep KEY_VOLUMEDOWN >/dev/null && sleep 0.5 && return 1
  done
}

choose() {
  ui_print "  - (+) YA | (-) TIDAK"
  if keytest; then
    return 0
  else
    return 1
  fi
}

ui_print " "
ui_print "==============================="
ui_print "    HyperOS 3 Custom Install   "
ui_print "==============================="
ui_print " "

ui_print "[?] Pasang Tema Settings?"
if choose; then
  ui_print "  -> Settings dipilih"
else
  ui_print "  -> Melewati Settings"
  rm -rf $MODPATH/system/media/theme/default/com.android.settings
fi

ui_print " "

ui_print "[?] Pasang Tema SystemUI?"
if choose; then
  ui_print "  -> SystemUI dipilih"
else
  ui_print "  -> Melewati SystemUI"
  rm -rf $MODPATH/system/media/theme/default/com.android.systemui
fi

ui_print " "

ui_print "[?] Pasang Tema SystemUI Plugin?"
if choose; then
  ui_print "  -> Plugin dipilih"
else
  ui_print "  -> Melewati Plugin"
  rm -rf $MODPATH/system/media/theme/default/miui.systemui.plugin
fi

ui_print " "

ui_print "[?] Pasang HyperOS 3 Icons?"
if choose; then
  ui_print "  -> Icons dipilih"
else
  ui_print "  -> Melewati Icons"
  rm -rf $MODPATH/system/media/theme/default/icons
fi

ui_print " "
ui_print "==============================="
ui_print "   Instalasi Selesai, Reboot!  "
ui_print "==============================="

  echo " - Done"
  sleep 1
  echo " - Starting additional script"
  sleep 1
mv $MODPATH/system/folder $MODPATH/system/product