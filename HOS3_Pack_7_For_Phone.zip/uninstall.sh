#!/system/bin/sh
#
rm /data/adb/service.d/battery.sh