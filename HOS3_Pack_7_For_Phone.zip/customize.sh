#!/sbin/sh
#
  echo " - Done"
  sleep 1
  echo " - Starting additional script"
  sleep 1
mv $MODPATH/system/folder $MODPATH/system/product